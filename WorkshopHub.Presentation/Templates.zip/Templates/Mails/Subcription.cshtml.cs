using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WorkshopHub.Presentation.Templates.Mails
{
    public class SubcriptionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
