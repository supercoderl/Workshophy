using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WorkshopHub.Presentation.Templates.Mails
{
    public class NewsletterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
