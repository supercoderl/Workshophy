using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WorkshopHub.Presentation.Templates.Mails
{
    public class TicketConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
