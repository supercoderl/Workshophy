using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WorkshopHub.Presentation.Templates.Mails
{
    public class OtpModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
